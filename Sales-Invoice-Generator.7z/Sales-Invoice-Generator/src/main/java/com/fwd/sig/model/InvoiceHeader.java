package com.fwd.sig.model;

import com.fwd.sig.utlitiy.FileUtility;

import java.util.ArrayList;

public class InvoiceHeader {
    private int numberItem;
    private String dateItem;
    private String customerNameItem;
    private ArrayList<InvoiceLine> invoiceLines;
    private double invoiceTotal = 0.0;

    public double getInvoiceTotal(){
        for (InvoiceLine line : getInvoiceLines()){
            invoiceTotal = invoiceTotal+ line.getTotalPrice();
        }
        return invoiceTotal;
    }

    public InvoiceHeader(int numberItem, String dateItem, String customerItem) {
        setNumberItem(numberItem);
        setDateItem(dateItem);
        setCustomerNameItem(customerItem);
        invoiceLines = new ArrayList<InvoiceLine>();
    }

    public ArrayList<InvoiceLine> getInvoiceLines() {
        if (invoiceLines == null){
            invoiceLines = new ArrayList();
        }
        return invoiceLines;
    }

    public String getCustomerNameItem() {
        return customerNameItem;
    }

    public int getNumberItem() {
        return numberItem;
    }

    public String getDateItem() {
        return dateItem;
    }

    public int getLineSize(){
        return invoiceLines.size();
    }

    public void setCustomerNameItem(String customerNameItem) {
        this.customerNameItem = customerNameItem;
    }

    public void setNumberItem(int numberItem) {
        this.numberItem = numberItem;
    }

    public void setDateItem(String dateItem) {
        this.dateItem = dateItem;
    }

    public void addInvoiceLine(InvoiceLine il){
        invoiceLines.add(il);
    }

    public void removeInvoiceLine(InvoiceLine invoiceLineObj){
        invoiceLines.remove(invoiceLineObj);
    }

    public String[] getTableFormat(){
        String[] data = new String[FileUtility.getInvoicesTableHeaders().length];
        data[0] = String.valueOf(getNumberItem());
        data[1] = getDateItem();
        data[2] = getCustomerNameItem();
        data[3] = String.valueOf(getInvoiceTotal());
        return data;
    }
}
