package com.fwd.sig.utlitiy;

public class Resources {
    public static final String[] INVOICES_HEADERS ={"No.","Date","Customer","Total"};
    public static final String[] INVOICES_ITEMS_HEADERS ={"No.","Item Name","Item Price","Item Count","Total"};
    public static String INVOICE_HEADER_PATH;
    public static String INVOICE_LINE_PATH;
    public static String INVOICE_HEADER_CSV= "InvoiceHeader.csv";
    public static String INVOICE_LINES_CSV= "InvoiceLine.csv";
    public static String CHOOSE_FILE_INVOICE_HEADER_MESSAGE = "Kindly choose the 'InvoiceHeader.csv' file :)";
    public static String CHOOSE_FILE_INVOICE_LINES_MESSAGE = "Kindly Choose the 'InvoiceLine.csv' file :)";
    public static String INVOICE_HEADER_EXCEPTION = "Kindly make sure to choose a file with the correct name and format of InvoiceHeader.csv";
    public static String INVOICE_LINES_EXCEPTION = "Kindly make sure to choose a file with the correct name and format of InvoiceLine.csv";
    public static String CHOOSE_FILE_TITLE = "Choose File";
    public static String delimiter_commas =",";
    public static String INVOICE_HEADER_NOT_FOUND="No header file found 'InvoiceHeader.csv'";
    public static String INVOICE_LINE_NOT_FOUND="No file found 'InvoiceLine.csv'";
    public static String ERROR_TITLE="Error !";
    public static String ERROR_IN_DATA_FORMAT_TITLE ="Error in data format! :(";
    public static String ERROR_IN_FILE_FORMAT_TITLE="Error in file format! :(";
    public static String ENTER_MANDATORY_DATA_TITLE="Enter the invoice data and Customer Name !";
    public static String ITEM_DETAILS_MESSAGE="Please input the item details";
    public static String ADD_MORE_BUTTON ="Add more item";
    public static String THANKS_BUTTON = "Thanks ...";
    public static String ITEM_NAME_LABEL="Item Name";
    public static String ITEM_PRICE_LABEL="Item Price";
    public static String ITEM_COUNT_LABEL="Item Count";
    public static String ITEM_TOTAL_LABEL="Total";
    public static String CUSTOMER_NAME_LABEL="Customer Name";
    public static String DATE_FORMAT_LABEL="DD-MM-YYYY";
    public static String INVOICES_TABLE_LABEL="Invoices Table";
    public static String INVOICE_NUMBER_LABEL="Invoice Number";
    public static String INVOICE_DATE_LABEL="Invoice Date";
    public static String INVOICE_ITEMS_LABEL="Invoice Items";
    public static String DATA_SUCCESSFULLY_SAVED="Data Saved Successfully";
    public static String PLEASE_SELECTED_ITEM = "please selected the invoice";
    public static String FILE_MENU="File";
    public static String LOAD_FILE_MENU = "Load File";
    public static String SAVE_FILE_MENU = "Save File";
    public static String CREATE_NEW_INVOICE_BUTTON="Create New Invoice";
    public static String DELETE_INVOICE_BUTTON="Delete Invoice";
    public static String SAVE_BUTTON="Save";
    public static String CANCEL_BUTTON="Cancel";





    //Invoices Table



}
