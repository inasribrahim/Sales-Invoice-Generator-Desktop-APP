package com.fwd.sig.controller;

import com.fwd.sig.utlitiy.FileUtility;
import com.fwd.sig.utlitiy.Resources;
import com.fwd.sig.view.SalesInvoiceGeneratorFrame;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Buttons implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();
        if ("C".equals(actionCommand)) {
            FileUtility.createInvoiceDialog();
        } else if ("D".equals(actionCommand)) {
            int indexInvoice = SalesInvoiceGeneratorFrame.viewInvoicesTable.getSelectedRow();
            if (indexInvoice == -1) {
            } else {
                FileUtility.deleteInvoiceByTableIndex(indexInvoice);
            }
        } else if ("SE".equals(actionCommand)) {
            String invoiceNumEmptyCheck = SalesInvoiceGeneratorFrame.getTextFieldsValues()[0];
            if (invoiceNumEmptyCheck.isEmpty()) {
                JOptionPane.showConfirmDialog(null, new JLabel(Resources.PLEASE_SELECTED_ITEM),
                        Resources.ERROR_TITLE, JOptionPane.DEFAULT_OPTION);
            } else {
                int invoiceNum = Integer.parseInt(invoiceNumEmptyCheck);
                FileUtility.userInvoiceItemDialogPopUp(FileUtility.getInvoice(invoiceNum));
                SalesInvoiceGeneratorFrame.updateTables();
            }
        } else if ("CE".equals(actionCommand)) {
            int indexInvoiceItem = SalesInvoiceGeneratorFrame.viewInvoicesItemsTable.getSelectedRow();

            if (indexInvoiceItem == -1) {
                JOptionPane.showConfirmDialog(null, new JLabel(""), Resources.ERROR_TITLE, JOptionPane.OK_CANCEL_OPTION);
            } else {
                FileUtility.deleteInvoiceItemByTableIndex(
                        (String) SalesInvoiceGeneratorFrame.viewInvoicesItemsTable.getValueAt(indexInvoiceItem, 0),
                        (String) SalesInvoiceGeneratorFrame.viewInvoicesItemsTable.getValueAt(indexInvoiceItem, 1)
                );
            }
        }
        }
    }

