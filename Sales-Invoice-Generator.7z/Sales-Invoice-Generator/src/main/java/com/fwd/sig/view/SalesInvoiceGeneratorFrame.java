package com.fwd.sig.view;

import com.fwd.sig.controller.Buttons;
import com.fwd.sig.controller.Controller;
import com.fwd.sig.controller.MenuItems;
import com.fwd.sig.utlitiy.FileUtility;
import com.fwd.sig.utlitiy.Resources;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;


public class SalesInvoiceGeneratorFrame extends JFrame {
    private static JTextField invoiceNumber = new JTextField();
    private static JTextField invoiceDate = new JTextField();
    private static JTextField invoiceCustomerName = new JTextField();
    private static JTextField invoiceTotalCost = new JTextField();
    public static JTable viewInvoicesTable = new Controller(Controller.INVOICES_TABLE).getTable();
    public static JTable viewInvoicesItemsTable = new Controller(Controller.INVOICE_ITEMS_TABLE).getTable();


    public SalesInvoiceGeneratorFrame(String name){
        super(name);
        setLocation(0,0);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(1,2));

        Buttons buttonsListener = new Buttons();
        MenuItems menuListener = new MenuItems();

        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu(Resources.FILE_MENU);
        menuBar.add(menu);
        JMenuItem load = new JMenuItem(Resources.LOAD_FILE_MENU);
        load.setActionCommand("L");
        load.addActionListener(menuListener);
        load.setMnemonic(KeyEvent.VK_L);
        load.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_L, ActionEvent.ALT_MASK));
        menu.add(load);
        JMenuItem save = new JMenuItem(Resources.SAVE_FILE_MENU);
        save.setActionCommand("S");
        save.addActionListener(menuListener);
        save.setMnemonic(KeyEvent.VK_S);
        save.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_S, ActionEvent.ALT_MASK));
        menu.add(save);
        this.setJMenuBar(menuBar);

        JPanel leftPanel=new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel,BoxLayout.Y_AXIS));
        leftPanel.setBorder(new EmptyBorder(new Insets(10, 20, 10, 15)));

        leftPanel.add(new JLabel(Resources.INVOICES_TABLE_LABEL));
        leftPanel.add(new JScrollPane(viewInvoicesTable));

        JPanel leftButtonsPanel = new JPanel();
        leftButtonsPanel.setLayout(new BoxLayout(leftButtonsPanel,BoxLayout.X_AXIS));
        JButton createBtn=new JButton(Resources.CREATE_NEW_INVOICE_BUTTON);
        createBtn.setActionCommand("C");
        createBtn.addActionListener(buttonsListener);
        JButton deleteBtn=new JButton(Resources.DELETE_INVOICE_BUTTON);
        deleteBtn.setActionCommand("D");
        deleteBtn.addActionListener(buttonsListener);
        leftButtonsPanel.add(createBtn);
        leftButtonsPanel.add(deleteBtn);
        leftPanel.add(leftButtonsPanel);
        this.add(leftPanel);


        JPanel rightPanel=new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel,BoxLayout.Y_AXIS));
        leftPanel.setBorder(new EmptyBorder(new Insets(10, 15, 10, 15)));

        JPanel rightInputsPanel = new JPanel();
        rightInputsPanel.setLayout(new GridLayout(4,2));
        invoiceNumber = new JTextField();
        invoiceDate = new JTextField();
        invoiceCustomerName = new JTextField();
        invoiceTotalCost = new JTextField();
        invoiceNumber.setEditable(false);
        invoiceTotalCost.setEditable(false);

        rightInputsPanel.add(new JLabel(Resources.INVOICE_NUMBER_LABEL));
        rightInputsPanel.add(invoiceNumber);
        rightInputsPanel.add(new JLabel(Resources.INVOICE_DATE_LABEL));
        rightInputsPanel.add(invoiceDate);
        rightInputsPanel.add(new JLabel(Resources.CUSTOMER_NAME_LABEL));
        rightInputsPanel.add(invoiceCustomerName);
        rightInputsPanel.add(new JLabel(Resources.ITEM_TOTAL_LABEL));
        rightInputsPanel.add(invoiceTotalCost);
        rightPanel.add(rightInputsPanel);

        rightPanel.add(new JLabel(Resources.INVOICE_ITEMS_LABEL));
        rightPanel.add(new JScrollPane(viewInvoicesItemsTable));

        JPanel rightButtonsPanel = new JPanel();
        rightButtonsPanel.setLayout(new BoxLayout(rightButtonsPanel,BoxLayout.X_AXIS));
        JButton saveButton=new JButton(Resources.SAVE_BUTTON);
        saveButton.setActionCommand("SE");
        saveButton.addActionListener(buttonsListener);

        JButton cancelButton=new JButton(Resources.CANCEL_BUTTON);
        cancelButton.setActionCommand("CE");
        cancelButton.addActionListener(buttonsListener);
        rightButtonsPanel.add(saveButton);
        rightButtonsPanel.add(cancelButton);
        rightPanel.add(rightButtonsPanel);
        this.add(rightPanel);

        this.pack();
    }

    public static void updateTextFields(String[] data){
        invoiceNumber.setText(data[0]);
        invoiceDate.setText(data[1]);
        invoiceCustomerName.setText(data[2]);
        invoiceTotalCost.setText(data[3]);

    }

    public static String[] getTextFieldsValues(){
        String[] data = new String[4];
        data[0] = invoiceNumber.getText();
        data[1] = invoiceDate.getText();
        data[2] = invoiceCustomerName.getText();
        data[3] = invoiceTotalCost.getText();
        return data;
    }

    public static void updateTables(){
        viewInvoicesTable.setModel(
                new Controller(FileUtility.getInvoicesTableData(),Controller.INVOICES_TABLE));
        viewInvoicesItemsTable.setModel(
                new Controller(FileUtility.getInvoicesItemsTableData(),Controller.INVOICE_ITEMS_TABLE));
    }

}
