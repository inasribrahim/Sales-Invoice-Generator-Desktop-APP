package com.fwd.sig.platform;

import com.fwd.sig.model.InvoiceHeader;
import com.fwd.sig.model.InvoiceLine;
import com.fwd.sig.utlitiy.FileUtility;
import com.fwd.sig.view.SalesInvoiceGeneratorFrame;

import java.util.ArrayList;

public class SalesInvoiceGeneratorApplication {
    public static void main(String[] args){ String appName = "Sales Invoice Generator";
    SalesInvoiceGeneratorFrame view = new SalesInvoiceGeneratorFrame(appName);
    view.setVisible(true);
    }

    public static void unitTest() {
        ArrayList<InvoiceHeader> invoices = FileUtility.getInvoices();
        for (int i = 0; i < invoices.size(); i++) {
            InvoiceHeader invoiceHeaderTest = invoices.get(i);
            System.out.print(invoiceHeaderTest.getNumberItem()+" :{ "+invoiceHeaderTest.getDateItem()+"\t\t|"+invoiceHeaderTest.getCustomerNameItem()+"\t\t|"+invoiceHeaderTest.getInvoiceTotal()+" }");
            System.out.println();
            for (InvoiceLine il : invoiceHeaderTest.getInvoiceLines()) {
                System.out.println(il.getItemCount()+"\t| "+il.getModuleName() + "\t|" + il.getItemCost() + "\t|" + il.getItemCount());
            }
            System.out.println("===========================================================");

        }

    }
}
