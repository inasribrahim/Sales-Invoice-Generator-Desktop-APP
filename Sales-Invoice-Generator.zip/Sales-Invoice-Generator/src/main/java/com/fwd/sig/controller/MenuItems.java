package com.fwd.sig.controller;

import com.fwd.sig.model.InvoiceHeader;
import com.fwd.sig.platform.SalesInvoiceGeneratorApplication;
import com.fwd.sig.utlitiy.FileUtility;
import com.fwd.sig.utlitiy.Resources;
import com.fwd.sig.view.SalesInvoiceGeneratorFrame;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class MenuItems implements ActionListener {
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();
        if ("L".equals(actionCommand)) {
            FileUtility.ReadFile();
            SalesInvoiceGeneratorApplication.unitTest();
            SalesInvoiceGeneratorFrame.updateTables();
        } else if ("S".equals(actionCommand)) {
            ArrayList<InvoiceHeader> ihs = FileUtility.getInvoices();
            FileUtility.WriteFile(ihs);
            JOptionPane.showConfirmDialog(null,
                    Resources.DATA_SUCCESSFULLY_SAVED, "", JOptionPane.DEFAULT_OPTION);
        }
    }
}
