package com.fwd.sig.model;

import com.fwd.sig.utlitiy.FileUtility;

public class InvoiceLine {

    private int itemNumber;
    private String moduleName;
    private double itemCost;
    private int itemCount;
    private InvoiceLine invoiceLine;

    public InvoiceLine(int itemNumber , String moduleName, double itemCost, int itemCount) {
        setItemNumber(itemNumber);
        setModuleName(moduleName);
        setItemCost(itemCost);
        setItemCount(itemCount);
    }

    public int getItemNumber(){ return itemNumber; }

    public int getItemCount(){ return itemCount; }

    public double getItemCost(){ return itemCost; }

    public InvoiceLine getInvoiceLine() { return invoiceLine; }

    public String getModuleName(){ return moduleName;}

    public double getTotalPrice(){ return (itemCost*itemCount) ; }

    public void setItemNumber(int itemNumber){ this.itemNumber = itemNumber;}

    public void setModuleName(String moduleName) {this.moduleName = moduleName;}

    public void setItemCount(int count){this.itemCount = count;}

    public void setItemCost(double cost){this.itemCost = cost;}

    public String[] getTableFormat(){
        String[] data = new String[FileUtility.getInvoicesItemsTableHeaders().length];
        data[0] = String.valueOf(getItemNumber());
        data[1] = getModuleName();
        data[2] = String.valueOf(getItemCost());
        data[3] = String.valueOf(getItemCount());
        data[4] = String.valueOf(getTotalPrice());
        return data;
    }

}
