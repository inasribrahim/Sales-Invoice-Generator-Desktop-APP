package com.fwd.sig.utlitiy;

import com.fwd.sig.model.InvoiceHeader;
import com.fwd.sig.model.InvoiceLine;
import com.fwd.sig.view.SalesInvoiceGeneratorFrame;

import javax.swing.*;
import java.io.*;
import java.text.ParseException;
import java.util.ArrayList;

public class FileUtility extends Resources{

    private static ArrayList<InvoiceHeader> allInvoicesData;
    private static ArrayList <InvoiceHeader> invoicesHeader;
    private static JPanel dialogPanel,dialogInvoicePanel;


    public static ArrayList<InvoiceHeader> readFile(){
        invoicesHeader = new ArrayList();
        JFileChooser fileChooser = new JFileChooser();
        JOptionPane.showConfirmDialog(null,
                CHOOSE_FILE_INVOICE_HEADER_MESSAGE, CHOOSE_FILE_TITLE, JOptionPane.DEFAULT_OPTION);
        fileChooser.showOpenDialog(fileChooser);
        BufferedReader bufferReader= null;
        INVOICE_HEADER_PATH = fileChooser.getSelectedFile().getPath();
        String line;

        try {
            if(!fileChooser.getSelectedFile().getName().equals(INVOICE_HEADER_CSV)){
                throw new Exception(INVOICE_HEADER_EXCEPTION);
            }
            bufferReader = new BufferedReader(new FileReader(INVOICE_HEADER_PATH));

            while ((line = bufferReader.readLine()) != null){
                String[] invoiceRow = line.split(delimiter_commas);
                String[] dateParts = invoiceRow[1].split("-");
                if (dateParts.length < 3 || dateParts.length < 0) {
                    JOptionPane.showMessageDialog(null, WRONG_FORMAT_DATE, ERROR_TITLE, JOptionPane.ERROR_MESSAGE);
                    System.exit(0);
                } else {
                    int day = Integer.parseInt(dateParts[0]);
                    int month = Integer.parseInt(dateParts[1]);
                    int year = Integer.parseInt(dateParts[2]);
                    if (day > 31 || month > 12) {
                        JOptionPane.showMessageDialog(null, WRONG_FORMAT_DATE, ERROR_TITLE, JOptionPane.ERROR_MESSAGE);
                        System.exit(0);
                    } else {
                        invoicesHeader.add(new InvoiceHeader(Integer.parseInt(invoiceRow[0]), invoiceRow[1], invoiceRow[2]));
                    }
                }
            }
        } catch (IOException ex) {
            JOptionPane.showConfirmDialog(null, new JLabel(INVOICE_HEADER_NOT_FOUND),ERROR_TITLE, JOptionPane.DEFAULT_OPTION);
            closeApp();
        } catch (ParseException ex) {
            JOptionPane.showConfirmDialog(null, new JLabel(ERROR_IN_DATA_FORMAT_TITLE), ERROR_TITLE, JOptionPane.OK_CANCEL_OPTION);
            closeApp();
        } catch (Exception ex){
            JOptionPane.showConfirmDialog(null, new JLabel(ex.getMessage()),ERROR_IN_FILE_FORMAT_TITLE, JOptionPane.DEFAULT_OPTION);
            return null;
        }


        JOptionPane.showConfirmDialog(null,
                CHOOSE_FILE_INVOICE_LINES_MESSAGE, CHOOSE_FILE_TITLE, JOptionPane.DEFAULT_OPTION);
        fileChooser.showOpenDialog(fileChooser);
        INVOICE_LINE_PATH = fileChooser.getSelectedFile().getPath();
        try {

            if(!fileChooser.getSelectedFile().getName().equals(INVOICE_LINES_CSV)){
                throw new Exception(INVOICE_LINES_EXCEPTION);
            }
            bufferReader = new BufferedReader(new FileReader(INVOICE_LINE_PATH));
            while ((line = bufferReader.readLine()) != null){
                String[] invoiceLineRow = line.split(delimiter_commas);

                for(int i =0;i<invoicesHeader.size();i++){
                    if(invoicesHeader.get(i).getNumberItem() == Integer.parseInt(invoiceLineRow[0])){
                        invoicesHeader.get(i).addInvoiceLine(
                                new InvoiceLine(Integer.parseInt(invoiceLineRow[0]),invoiceLineRow[1],Double.parseDouble(invoiceLineRow[2]),Integer.parseInt(invoiceLineRow[3]))
                        );
                    }
                }
            }
        } catch (IOException ex) {
            JOptionPane.showConfirmDialog(null, new JLabel("No file found 'InvoiceLine.csv'"),ERROR_TITLE, JOptionPane.DEFAULT_OPTION);
            closeApp();
        } catch (Exception ex) {
            JOptionPane.showConfirmDialog(null, new JLabel(ex.getMessage()),ERROR_IN_FILE_FORMAT_TITLE, JOptionPane.DEFAULT_OPTION);
        }
        allInvoicesData = invoicesHeader;
        return invoicesHeader;
    }


    public static void WriteFile(ArrayList<InvoiceHeader> dataRows){
        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter(new File(INVOICE_HEADER_PATH));
            for (InvoiceHeader data : dataRows) {
                StringBuilder line = new StringBuilder();
                line.append(data.getNumberItem());line.append(delimiter_commas);
                line.append(data.getDateItem());line.append(delimiter_commas);
                line.append(data.getCustomerNameItem());line.append(delimiter_commas);
                line.append("\n");
                fileWriter.write(line.toString());
            }
            fileWriter.close();
            } catch (IOException e) {
            JOptionPane.showConfirmDialog(null, new JLabel(INVOICE_HEADER_NOT_FOUND)
                    ,ERROR_TITLE, JOptionPane.OK_CANCEL_OPTION);
            closeApp();

        }

        try {
            fileWriter = new FileWriter(new File(INVOICE_LINE_PATH));
            for (InvoiceHeader data : dataRows) {
                for(InvoiceLine lineDetails : data.getInvoiceLines()){
                    StringBuilder line = new StringBuilder();
                    line.append(lineDetails.getItemNumber());line.append(delimiter_commas);
                    line.append(lineDetails.getModuleName());line.append(delimiter_commas);
                    line.append(lineDetails.getItemCost());line.append(delimiter_commas);
                    line.append(lineDetails.getItemCount());line.append(delimiter_commas);
                    line.append("\n");
                    fileWriter.write(line.toString());
                }
            }

            fileWriter.close();
        } catch (IOException ex) {
            JOptionPane.showConfirmDialog(null, new JLabel(INVOICE_LINE_NOT_FOUND)
                    ,ERROR_TITLE, JOptionPane.OK_CANCEL_OPTION);
            closeApp();
        }


    }

    public static ArrayList<InvoiceHeader> getInvoices(){
        return allInvoicesData;
    }

    public static InvoiceHeader getInvoice(int invoiceNo){
        for(InvoiceHeader invoice: allInvoicesData){
            if(invoice.getNumberItem() == invoiceNo){
                return invoice;
            }
        }
        return null;
    }

    public static String[] getInvoicesTableHeaders(){
        return INVOICES_HEADERS;
    }

    public static String[][] getInvoicesTableData(){
        String[][] data;
        data = new String[allInvoicesData.size()][INVOICES_HEADERS.length];

        for(int i = 0; i< allInvoicesData.size(); i++){
            data[i] = allInvoicesData.get(i).getTableFormat();
        }

        return data;
    }

    public static String[] getInvoicesItemsTableHeaders(){
        return INVOICES_ITEMS_HEADERS;
    }

    public static String[][] getInvoicesItemsTableData(){
        String[][] data;
        int itemsCount =0;
        for(InvoiceHeader invoice: allInvoicesData){
            itemsCount+=invoice.getInvoiceLines().size();
        }
        data = new String[itemsCount][INVOICES_ITEMS_HEADERS.length];
        itemsCount =0;

        for(int i = 0; i< allInvoicesData.size(); i++){
            InvoiceHeader invoiceLine = allInvoicesData.get(i);
            for(InvoiceLine invoiceLineArray: invoiceLine.getInvoiceLines()){
                data[itemsCount]= invoiceLineArray.getTableFormat();
                itemsCount++;
            }
        }

        return data;
    }

    public static String[][] getInvoicesItemsTableData(int invoiceNo){
        String[][] data;
        int itemsCount = 0;
        InvoiceHeader ih = null;

        for(InvoiceHeader invoice: allInvoicesData){
            if(invoice.getNumberItem() == invoiceNo){
                ih = invoice;
                itemsCount=ih.getInvoiceLines().size();
            }
        }

        data = new String[itemsCount][INVOICES_ITEMS_HEADERS.length];
        itemsCount =0;

        for(InvoiceLine il: ih.getInvoiceLines()){
            data[itemsCount]= il.getTableFormat();
            itemsCount++;
        }
        return data;
    }

    public static String[] getInvoiceData(int invoiceNo){
        String[] data = null;
        int itemsCount = 0;

        for(InvoiceHeader invoice: allInvoicesData){
            if(invoice.getNumberItem() == invoiceNo){
                data = invoice.getTableFormat();
            }
        }

        return data;
    }

    public static void updateInvoice(String[] data){
        for(InvoiceHeader ih: allInvoicesData){
            if(ih.getNumberItem() == Integer.parseInt(data[0])){
                ih.setDateItem(data[1]);
                ih.setCustomerNameItem(data[2]);
            }
        }
        SalesInvoiceGeneratorFrame.updateTables();
    }


    public static InvoiceHeader addInvoice(String[] data){
        InvoiceHeader invoice = new InvoiceHeader(
                allInvoicesData.get(allInvoicesData.size()-1).getNumberItem()+1, data[0], data[1]);

        allInvoicesData.add(invoice);
        return invoice;
    }

    public static void deleteInvoice(String invoiceNo){
        for(InvoiceHeader invoice: allInvoicesData){
            if(invoice.getNumberItem() == Integer.parseInt(invoiceNo)){
                allInvoicesData.remove(invoice);
            }
        }
        SalesInvoiceGeneratorFrame.updateTables();
    }

    public static void deleteInvoiceByTableIndex(int invoiceNo){
        allInvoicesData.remove(invoiceNo);
        SalesInvoiceGeneratorFrame.updateTables();
    }

    public static void deleteInvoiceItemByTableIndex(String invoiceIndex,String invoiceItem){
        for(InvoiceHeader ih: allInvoicesData){
            if(ih.getNumberItem() == Integer.parseInt(invoiceIndex)){
                for(InvoiceLine il: ih.getInvoiceLines()){
                    if(il.getModuleName().equals(invoiceItem)){
                        ih.removeInvoiceLine(il);
                        break;
                    }
                }
            }
        }
        SalesInvoiceGeneratorFrame.updateTables();
    }


    public static void createInvoiceDialog(){
        JTextField dateField = new JTextField(10);
        JTextField nameField = new JTextField(50);

        dialogInvoicePanel = new JPanel();
        dialogInvoicePanel.add(new JLabel(DATE_FORMAT_LABEL));
        dialogInvoicePanel.add(dateField);
        dialogInvoicePanel.add(Box.createHorizontalStrut(15));
        dialogInvoicePanel.add(new JLabel(CUSTOMER_NAME_LABEL));
        dialogInvoicePanel.add(nameField);

        String[] data = new String[2];
        int result = JOptionPane.showConfirmDialog(null, dialogInvoicePanel,
                ENTER_MANDATORY_DATA_TITLE, JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            data[0] = dateField.getText();
            data[1] = nameField.getText();
            userInvoiceItemDialogPopUp(addInvoice(data));
            SalesInvoiceGeneratorFrame.updateTables();
        }
    }


    public static void userInvoiceItemDialogPopUp(InvoiceHeader invoice){
        JTextField itemNameField = new JTextField(50);
        JTextField itemPriceField = new JTextField(4);
        JTextField itemCountField = new JTextField(5);

        dialogPanel = new JPanel();
        dialogPanel.add(new JLabel(ITEM_NAME_LABEL));
        dialogPanel.add(itemNameField);
        dialogPanel.add(Box.createHorizontalStrut(15));
        dialogPanel.add(new JLabel(ITEM_PRICE_LABEL));
        dialogPanel.add(itemPriceField);
        dialogPanel.add(Box.createHorizontalStrut(15));
        dialogPanel.add(new JLabel(ITEM_COUNT_LABEL));
        dialogPanel.add(itemCountField);

        String[] data = new String[3];

        int result= JOptionPane.showOptionDialog(null,
                dialogPanel,
                ITEM_DETAILS_MESSAGE,
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                new String[]{ADD_MORE_BUTTON, THANKS_BUTTON},
                "default");

        data[0] = itemNameField.getText();
        data[1] = itemPriceField.getText();
        data[2] = itemCountField.getText();

        InvoiceLine invoiceLineInstance = new InvoiceLine(invoice.getNumberItem(),data[0],Double.parseDouble(data[1]),Integer.parseInt(data[2]));
        invoice.addInvoiceLine(invoiceLineInstance);
        if (result == JOptionPane.OK_OPTION) {
            userInvoiceItemDialogPopUp(invoice);
        }
    }

    public static void closeApp(){
        System.exit(0);
    }
}
